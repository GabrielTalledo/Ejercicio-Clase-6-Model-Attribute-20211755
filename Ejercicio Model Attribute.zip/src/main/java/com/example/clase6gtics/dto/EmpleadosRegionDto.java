package com.example.clase6gtics.dto;

public interface EmpleadosRegionDto {
    String getRegiondescription();
    int getCantidadempleados();
}
